# 项目依赖与环境配置说明

## 1. JDK 11 及以上
请确保已安装 JDK 11 或更高版本，并配置好 JAVA_HOME 环境变量。

## 2. Maven 3.6 及以上
请确保已安装 Maven，并配置好 MAVEN_HOME 环境变量。

## 3. OpenCV 4.10.0
- 下载地址：https://opencv.org/releases/
- 解压后找到 `opencv/build/java/x64/opencv_java4100.dll`
- 建议将该 DLL 文件复制到 `opencv_dll` 目录（如 `G:\项目文件\Inexist\opencv_dll`）
- 运行时需添加 VM 参数：
  
  ```
  -Djava.library.path=G:\项目文件\Inexist\opencv_dll
  ```

## 4. Tesseract-OCR
- 下载地址：https://github.com/tesseract-ocr/tesseract
- 安装后将 `tessdata` 目录路径配置到环境变量，或确保 `tessdata` 目录与程序同级

## 5. 安装依赖
在项目根目录下执行：

```
mvn clean install
```

## 6. 一键环境配置与启动
可直接运行 `setup.bat` 脚本自动配置环境并启动项目。

---
如遇问题请联系开发者或查阅 README 及相关文档。
