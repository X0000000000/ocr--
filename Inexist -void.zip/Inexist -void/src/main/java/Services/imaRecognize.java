package Services;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import java.io.File;

public class imaRecognize {

    /**
     * 使用Tess4J进行图片文字识别
     * @param imagePath 图片文件路径
     * @param language 识别语言（如"eng"、"chi_sim"等）
     * @return 识别到的文本内容
     */
    public static String recognizeImage(String imagePath, String language) {
        System.out.println("Image recognition service initialized.");
        String result = "";
        try {
            Tesseract instance = new Tesseract();
            if (language != null && !language.isEmpty()) {
                instance.setLanguage(language);
            } else {
                instance.setLanguage("eng");
            }
            // 设置 Tesseract 数据路径（如果需要）
            // instance.setDatapath("path/to/tessdata");
            // 设置页面分割模式
            instance.setPageSegMode(6); // 假设输入是一个统一的文本块
            result = instance.doOCR(new File(imagePath));
            System.out.println("Recognized text: " + result);
        } catch (TesseractException e) {
            System.err.println("Tesseract识别异常: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("图片识别异常: " + e.getMessage());
        }
        return result;
        //将警告用System.err.println()输出，不影响程序运行
    }

    public static void main(String[] args) {
        String imagePath = "C:\\Users\\HONOR\\Desktop\\新建文件夹\\1_书法古诗.jpg";
        String language = "chi_sim";
        recognizeImage(imagePath, language);
    }
}

//OpenCV 的 EAST 文本检测器
