package Services;

import py4j.GatewayServer;

public class Connection {

    public String addressField() {
        String address = "http://localhost:25333/ImageRecon/src/GUI/java_connect.java";
        return address;
    }

    public void printMessage() {
        System.out.println("Hello from Java!");
    }

    public static void connect() {
        Connection app = new Connection();
        GatewayServer.turnLoggingOn();
        GatewayServer server = new GatewayServer(app, 25333);
        server.start();
        System.out.println("Gateway started");
        System.out.println("Waiting for client to connect");

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Shutting down the gateway server...");
            server.shutdown();
        }));
    }

    public static void main(String[] args) {
        connect();
    }
}