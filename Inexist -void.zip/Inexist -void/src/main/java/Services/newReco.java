//使用EasyOCR库识别图片中的文字
