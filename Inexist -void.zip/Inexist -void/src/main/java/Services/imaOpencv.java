package Services;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import java.io.File;

public class imaOpencv {
    static {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        System.out.println("OpenCV loaded.");
    }

    public imaOpencv() {
        System.out.println("OpenCV service initialized.");
        // 这里可以添加OpenCV相关的初始化代码
        System.out.println("OpenCV service ready to process images.");
    }

    /**
     * 处理图片并进行OCR识别
     * @param imagePath 输入图片路径
     * @param processedImagePath 处理后图片保存路径
     * @param language 识别语言（如"eng"）
     * @return 识别结果字符串
     */
    public String processImage(String imagePath, String processedImagePath, String language) {
        System.out.println("Processing image at: " + imagePath);
        preprocessImageForOCR(imagePath, processedImagePath);
        String result = recognizeText(processedImagePath, language);
        System.out.println("识别结果:\n" + result);
        return result;
    }

    // 图像预处理
    private void preprocessImageForOCR(String inputPath, String outputPath) {
        Mat src = Imgcodecs.imread(inputPath, Imgcodecs.IMREAD_COLOR);
        if (src.empty()) {
            System.out.println("无法加载图像: " + inputPath);
            return;
        }
        // 转换为灰度
        Mat gray = new Mat();
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY);
        // 高斯模糊
        Mat blurred = new Mat();
        Imgproc.GaussianBlur(gray, blurred, new Size(3, 3), 0);
        // 自适应阈值
        Mat binary = new Mat();
        Imgproc.adaptiveThreshold(blurred, binary, 255,
                Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C,
                Imgproc.THRESH_BINARY, 11, 2);
        // 形态学操作
        Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(3, 3));
        Mat morphed = new Mat();
        Imgproc.morphologyEx(binary, morphed, Imgproc.MORPH_CLOSE, kernel);
        // 保存处理后的图像
        Imgcodecs.imwrite(outputPath, morphed);
    }

    // OCR识别
    private String recognizeText(String imagePath, String language) {
        Tesseract tesseract = new Tesseract();
        try {
            // 请根据实际情况设置tessdata的绝对路径或相对路径
            tesseract.setDatapath("tessdata");
            tesseract.setLanguage(language);
            return tesseract.doOCR(new File(imagePath));
        } catch (TesseractException e) {
            System.err.println("OCR错误: " + e.getMessage());
            return "";
        }
    }

    public static void main(String[] args) {
        // 示例：输入图片路径、输出处理后图片路径、识别语言
        String inputImagePath = "G:\\项目文件\\javaproject\\testphoto\\example.png";
        String processedImagePath = "G:\\项目文件\\javaproject\\testphoto\\example_processed.png";
        String language = "eng";
        imaOpencv service = new imaOpencv();
        service.processImage(inputImagePath, processedImagePath, language);
    }
}