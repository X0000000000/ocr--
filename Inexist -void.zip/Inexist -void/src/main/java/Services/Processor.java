package Services;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.util.Set;

public class Processor {
    /**
     * 优化内存和线程资源，尽量释放JVM可用资源。
     * 注意：不能强制关闭系统线程和外部程序，只能请求中断自定义线程和进行垃圾回收。
     */
    public static void optimizeSystem() {
        // 清理缓存
        System.out.println("清理缓存");
        System.gc();
        System.out.println("已请求JVM进行垃圾回收");

        // 关闭多余的线程
        System.out.println("关闭多余的线程");
        Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
        for (Thread t : threadSet) {
            if (!t.isDaemon() && t != Thread.currentThread() && t.getClass().getClassLoader() != null) {
                // 只中断自定义线程，避免影响JVM核心线程
                t.interrupt();
                System.out.println("已请求中断线程: " + t.getName());
            }
        }

        // 关闭清理缓存线程（此处无专门线程，仅演示）
        System.out.println("关闭清理缓存线程");
        // 如果有专门的清理线程，可在此中断

        // 清理优化电脑正在运行的程序（仅限JVM内存）
        System.out.println("清理优化电脑正在运行的程序");
        MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
        MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();
        System.out.println("当前堆内存使用: " + heapUsage.getUsed() / 1024 / 1024 + " MB");

        // 重复操作，直到电脑的内存占用最小或达到安全阈值
        int count = 0;
        while (heapUsage.getUsed() > 100 * 1024 * 1024 && count < 5) { // 最多尝试5次
            System.gc();
            try { Thread.sleep(200); } catch (InterruptedException ignored) {}
            heapUsage = memoryBean.getHeapMemoryUsage();
            System.out.println("当前堆内存使用: " + heapUsage.getUsed() / 1024 / 1024 + " MB");
            count++;
        }
        System.out.println("优化完成");
    }

    public static void main(String[] args) {
        optimizeSystem();
    }
}
