package Dao;

import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;

public class MongoDB {
    //将数据库连接至本地mongodb数据库，数据库与保存至数据库按钮相关联，点击按钮后，数据库连接成功，并打印数据库名称
    public static void connectDatabase() {
        String url = "mongodb://localhost:27017";
        MongoClient mongoClient= MongoClients.create(new ConnectionString(url));
        MongoDatabase database = mongoClient.getDatabase("orcdatabase");
        System.out.println(database.getName()+"连接成功");
        //关闭数据库连接
        mongoClient.close();
        System.out.println("数据库连接已关闭");
    }

    // 保存txt文件到MongoDB
    public static void saveTxtToDb(String fileName, String content) {
        String url = "mongodb://localhost:27017";
        try (MongoClient mongoClient = MongoClients.create(new ConnectionString(url))) {
            MongoDatabase database = mongoClient.getDatabase("orcdatabase");
            MongoCollection<Document> collection = database.getCollection("txtfiles");
            // 先删除同名文件（如有）
            collection.deleteOne(Filters.eq("fileName", fileName));
            Document doc = new Document("fileName", fileName).append("content", content);
            collection.insertOne(doc);
        }
    }

    // 获取所有txt文件名
    public static List<String> listTxtFiles() {
        String url = "mongodb://localhost:27017";
        List<String> fileNames = new ArrayList<>();
        try (MongoClient mongoClient = MongoClients.create(new ConnectionString(url))) {
            MongoDatabase database = mongoClient.getDatabase("orcdatabase");
            MongoCollection<Document> collection = database.getCollection("txtfiles");
            for (Document doc : collection.find()) {
                fileNames.add(doc.getString("fileName"));
            }
        }
        return fileNames;
    }

    // 根据文件名获取txt内容
    public static String getTxtContent(String fileName) {
        String url = "mongodb://localhost:27017";
        try (MongoClient mongoClient = MongoClients.create(new ConnectionString(url))) {
            MongoDatabase database = mongoClient.getDatabase("orcdatabase");
            MongoCollection<Document> collection = database.getCollection("txtfiles");
            Document doc = collection.find(Filters.eq("fileName", fileName)).first();
            if (doc != null) {
                return doc.getString("content");
            }
        }
        return "";
    }

    // 批量删除指定txt文件
    public static void deleteTxtFiles(List<String> fileNames) {
        String url = "mongodb://localhost:27017";
        try (MongoClient mongoClient = MongoClients.create(new ConnectionString(url))) {
            MongoDatabase database = mongoClient.getDatabase("orcdatabase");
            MongoCollection<Document> collection = database.getCollection("txtfiles");
            for (String fileName : fileNames) {
                collection.deleteOne(Filters.eq("fileName", fileName));
            }
        }
    }

    // 删除指定txt文件
    public static void deleteTxtFile(String fileName) {
        String url = "mongodb://localhost:27017";
        try (MongoClient mongoClient = MongoClients.create(new ConnectionString(url))) {
            MongoDatabase database = mongoClient.getDatabase("orcdatabase");
            MongoCollection<Document> collection = database.getCollection("txtfiles");
            collection.deleteOne(Filters.eq("fileName", fileName));
        }
    }

    public static void main(String[] args) {
        connectDatabase();
    }
}

