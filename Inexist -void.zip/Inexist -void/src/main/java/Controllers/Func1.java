package Controllers;

import Controllers.Func.imaReconFun;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class Func1 { // 类名首字母大写
    private VBox mainContent;
    private Button func1Button;
    private Button func2Button;
    private boolean buttonsVisible = false;

    public Func1(VBox mainContent) {
        this.mainContent = mainContent;
        func1Button = Controllers.Controller.createStyledButton("图像转文字", e -> {
            System.out.println("func1 button clicked");
            Controllers.Controller controller = Controllers.Controller.mainContentStatic != null ? (Controllers.Controller)Controllers.Controller.mainContentStatic.getProperties().get("controller") : null;
            if (controller != null) {
                controller.showFunc1Tab();
            }
        });
        func2Button = Controllers.Controller.createStyledButton("func2", e -> System.out.println("func2 button clicked"));
    }

    public static Button getFunc1Button() {
        // 返回func1Button的实例
        return new Func1(new VBox()).func1Button;
    }

    // 切换显示/隐藏
    public void toggleButtons() {
        if (buttonsVisible) {
            mainContent.getChildren().removeAll(func1Button, func2Button);
        } else {
            mainContent.getChildren().addAll(func1Button, func2Button);
        }
        buttonsVisible = !buttonsVisible;
    }

    // 新增：强制隐藏Func1和Func2按钮
    public void hideButtons() {
        mainContent.getChildren().removeAll(func1Button, func2Button);
        buttonsVisible = false;
    }

    //运行imaReconFun，并将其结果显示在界面上
    public void runImaReconFun() {
        // 这里可以调用imaReconFun的相关方法
        System.out.println("Running imaReconFun...");

    }

    public static void main(String[] args) {
        imaReconFun.main(args);
        // 运行imaReconFun。并将其结果显示在界面上

        Func1 func1 = new Func1(new VBox());
        func1.toggleButtons();
        func1.runImaReconFun();
        // 这里可以添加更多的测试代码
        System.out.println("Func1 main method executed.");

    }
}

