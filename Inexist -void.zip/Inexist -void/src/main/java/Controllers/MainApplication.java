package Controllers;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Setting setting = new Setting();

        double fixedWidth = setting.screenWidth;
        double fixedHeight = setting.screenHeight;

        Color backgroundColor = setting.getBackgroundColor();

        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource(
                "hello-view.fxml"));

        Scene scene = new Scene(fxmlLoader.load(), fixedWidth, fixedHeight);
        scene.setFill( backgroundColor );
        stage.setTitle("INexist");
        stage.setScene(scene);
        stage.show();
        // 设置界面成功启动时间
        Controllers.Controller controller = fxmlLoader.getController();
        if (controller != null) {
            controller.setEndTime();
            // 新增：运行Processor并将结果传递给History Tab
            String processorResult = runProcessorAndGetResult();
            controller.setHistoryProcessorResult(processorResult);
        }
    }

    // 新增：运行Processor并获取其输出
    private String runProcessorAndGetResult() {
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        java.io.PrintStream oldOut = System.out;
        System.setOut(new java.io.PrintStream(baos));
        try {
            Services.Processor.optimizeSystem();
        } finally {
            System.setOut(oldOut);
        }
        return baos.toString();
    }

    public static void main(String[] args) {
        launch();
    }
}

