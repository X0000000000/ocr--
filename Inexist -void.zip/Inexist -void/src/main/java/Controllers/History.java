package Controllers;

import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.VBox;
import java.util.Date;

public class History {
    private long startTimeMillis;
    private long endTimeMillis;
    private String historyProcessorResult;
    private Label historyTabLabel;

    public History(long startTimeMillis) {
        this.startTimeMillis = startTimeMillis;
        this.endTimeMillis = 0;
        this.historyProcessorResult = null;
    }

    public void setEndTime(long endTimeMillis) {
        this.endTimeMillis = endTimeMillis;
    }

    public void setHistoryProcessorResult(String result) {
        this.historyProcessorResult = result;
    }

    public void setHistoryTabLabel(Label label) {
        this.historyTabLabel = label;
    }

    public void updateHistoryTabContent() {
        if (historyTabLabel != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("Operation History:\n1. Setting button clicked\n2. History button clicked\n\n");
            sb.append("启动时间: ").append(new Date(startTimeMillis)).append("\n");
            if (endTimeMillis > 0) {
                sb.append("界面成功启动时间: ").append(new Date(endTimeMillis)).append("\n");
                sb.append("启动耗时: ").append((endTimeMillis - startTimeMillis)).append(" ms\n");
            } else {
                sb.append("界面成功启动时间: (未完成)\n");
            }
            if (historyProcessorResult != null && !historyProcessorResult.isEmpty()) {
                sb.append("\n[系统优化信息]\n");
                sb.append(historyProcessorResult);
            }
            historyTabLabel.setText(sb.toString());
        }
    }

    public void showHistoryTab(TabPane mainTabPane) {
        Tab historyTab = null;
        for (Tab tab : mainTabPane.getTabs()) {
            if ("History".equals(tab.getText())) {
                historyTab = tab;
                break;
            }
        }
        if (historyTab == null) {
            Tab newHistoryTab = new Tab("History");
            VBox historyContent = Controllers.Controller.createStyledTabContent("", "-fx-text-fill: #fff; -fx-font-size: 18px;", "-fx-background-color: #222222; -fx-padding: 20;");
            Label label = (Label) historyContent.getChildren().get(0);
            setHistoryTabLabel(label);
            newHistoryTab.setContent(historyContent);
            mainTabPane.getTabs().add(newHistoryTab);
            mainTabPane.getSelectionModel().select(newHistoryTab);
            updateHistoryTabContent();
        } else {
            mainTabPane.getSelectionModel().select(historyTab);
            updateHistoryTabContent();
        }
    }

    public static void main(String[] args) {

    }
}
