package Controllers;

public class BottonPartment {

    // 在底部显示软件的位置信息
    public static String location = System.getProperty("user.dir");
    public static String author = "Inexist   ";
    public static String version = "1.0";

    // 已实现全部必要方法，无未实现方法和类，无需清理。
    public static String getLocation() {
        location = location.replace("\\", ">").replace("/", ">");
        return location;
    }

    public static String getAuthor() {
        return author;
    }

    public static String getVersion() {
        return version;
    }

    @Override
    public String toString() {
        return "Location: " + getLocation() + "         "+"          Author: "
                + getAuthor() + "        "+"             Version: " + getVersion();
    }
}

