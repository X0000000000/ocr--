package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Window;
import java.io.File;
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.FileWriter;
import java.io.IOException;

import Services.imaRecognize;
import javafx.scene.layout.FlowPane;

import java.util.ArrayList;
import javafx.scene.layout.AnchorPane;

public class Controller {

    public Button func1Button;
    @FXML
    private Label welcomeText;

    @FXML
    private Label versionLabel;

    @FXML
    private Label authorLabel;

    @FXML
    private Label locationLabel;

    @FXML
    private VBox mainContent;

    @FXML
    private javafx.scene.control.Button settingButton;
    @FXML
    private javafx.scene.control.Button historyButton;
    @FXML
    private javafx.scene.control.Button functionButton;
    @FXML
    private javafx.scene.control.Button helloButton;

    @FXML
    private TabPane mainTabPane; // 主标签栏

    @FXML
    private Label startTimeLabel;
    @FXML
    private Label endTimeLabel;
    private long startTimeMillis;
    private long endTimeMillis; // 新增：记录结束时间

    public static VBox mainContentStatic;

    private Func1 func1; // 修改为首字母大写

    // 保存Functions标签页的内容状态
    private VBox functionsTabContentCache = null;

    @FXML
    private ImageView previewImageView;
    @FXML
    private Button recognizeButton;
    @FXML
    private TextArea resultTextArea;
    @FXML
    private Button exportTxtButton;

    @FXML
    private TextArea functionsResultTextArea;

    private File lastSelectedImageFile = null; // 记录最后一次选择的图片

    // 图片管理
    private List<File> importedImages = new ArrayList<>();
    private List<File> recycleBinImages = new ArrayList<>();

    @FXML
    private FlowPane imagePreviewPane;
    @FXML
    private FlowPane recycleBinPane;
    @FXML
    private ScrollPane recycleBinScrollPane;
    @FXML
    private Button recycleBinButton;

    // 新增：Processor运行结果内容
    private String historyProcessorResult = null;

    @FXML
    private Button importBtn; // 对应functions-view.fxml的导入按钮
    @FXML
    private Button recognizeBtn; // 对应functions-view.fxml的识别按钮
    @FXML
    private Button exportBtn; // 对应functions-view.fxml的导出按钮
    @FXML
    private Button clearAllBtn; // 对应functions-view.fxml的清除按钮
    @FXML
    private Button importTxtToDbBtn; // 新增：对应functions-view.fxml的txt导入数据库按钮

    @FXML
    private HBox bottomBar;

    @FXML
    private Label bottomInfoLabel;

    private History history;

    @FXML
    public void initialize() {
        mainContentStatic = mainContent;
        // 设置底部栏样式与BottonPartment一致
        if (bottomBar != null) {
            bottomBar.setStyle("-fx-background-color:#BDC3C7; -fx-border-color: #FFFFFF;-fx-border-width: 1px;");
        }
        // 一次性显示全部底部信息
        if (bottomInfoLabel != null) {
            bottomInfoLabel.setText(new BottonPartment().toString());
        }
        // 设置Setting按钮为齿轮形状
        // 已移除齿轮SVG相关代码，保留按钮功能
        if (settingButton != null) {
            settingButton.setText("");
            settingButton.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
            Tooltip.install(settingButton, new Tooltip("Setting"));
        }
        // 只有mainContent、versionLabel等不为null时才设置
        if (versionLabel != null) versionLabel.setText("Version: " + BottonPartment.getVersion());
        if (authorLabel != null) versionLabel.setText("Author: " + BottonPartment.getAuthor());
        if (locationLabel != null) versionLabel.setText("Location: " + BottonPartment.getLocation());
        func1 = new Func1(mainContent != null ? mainContent : new VBox()); // 防止mainContent为null
        // 初始化TabPane（如果FXML未定义，可在此处new并加入mainContent）
        if (mainTabPane == null && mainContent != null) {
            mainTabPane = new TabPane();
            mainContent.getChildren().add(0, mainTabPane);
        }
        // 启动时间
        startTimeMillis = System.currentTimeMillis();
        history = new History(startTimeMillis);
        if (startTimeLabel != null) {
            startTimeLabel.setText("启动时间: " + new java.util.Date(startTimeMillis));
        }
        // 兼容functions-view.fxml无startTimeLabel时不报错
        if (mainContent != null || imagePreviewPane != null) {
            refreshImagePreview();
            refreshRecycleBin();
        }
        if (recycleBinScrollPane != null) {
            recycleBinScrollPane.setVisible(false);
            recycleBinScrollPane.setManaged(false);
        }
        // 程序启动时自动显示Home Tab，Home里有MongoDBPage按钮
        onHomeButtonClick(null);
    }

    // 提供方法供MainApplication调用，设置结束时间
    public void setEndTime() {
        endTimeMillis = System.currentTimeMillis();
        if (endTimeLabel != null) {
            endTimeLabel.setText("界面成功启动时间: " + new java.util.Date(endTimeMillis));
        }
        if (history != null) history.setEndTime(endTimeMillis);
        if (history != null) history.updateHistoryTabContent();
    }

    // 新增：设置Processor运行结果
    public void setHistoryProcessorResult(String result) {
        this.historyProcessorResult = result;
        if (history != null) history.setHistoryProcessorResult(result);
        if (history != null) history.updateHistoryTabContent();
    }

    public void onSettingButtonClick(ActionEvent actionEvent) {
        System.out.println("Setting button clicked");
        setMainButtonsDisable(true);
        func1.hideButtons(); // 强制隐藏Func1和Func2按钮
        // 检查是否已存在Setting标签
        Tab settingTab = null;
        for (Tab tab : mainTabPane.getTabs()) {
            if ("Setting".equals(tab.getText())) {
                settingTab = tab;
                break;
            }
        }
        if (settingTab == null) {
            Tab newSettingTab = new Tab("Setting");
            VBox vbox = new VBox(20);
            vbox.setStyle("-fx-background-color: #BDC3C7; -fx-padding: 20;");
            vbox.setAlignment(javafx.geometry.Pos.CENTER);
            Label bgLabel = new Label("请选择背景颜色：");
            bgLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #222;");
            ComboBox<String> bgCombo = new ComboBox<>();
            bgCombo.getItems().addAll("默认", "浅灰 #F0F2F5", "深灰 #222222", "蓝灰 #BDC3C7");
            bgCombo.setValue("蓝灰 #BDC3C7");
            Label fontLabel = new Label("请选择字体：");
            fontLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #222;");
            ComboBox<String> fontCombo = new ComboBox<>();
            fontCombo.getItems().addAll("微软雅黑", "宋体", "黑体", "Arial", "Times New Roman");
            fontCombo.setValue("微软雅黑");
            Label fontSizeLabel = new Label("请选择字体大小：");
            fontSizeLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #222;");
            ComboBox<String> fontSizeCombo = new ComboBox<>();
            fontSizeCombo.getItems().addAll("14", "16", "18", "20", "22", "24", "28", "32");
            fontSizeCombo.setValue("18");
            Button saveBtn = new Button("保存更改");
            saveBtn.setStyle("-fx-font-size: 15px; -fx-background-color: #4CAF50; -fx-text-fill: #fff;");
            saveBtn.setOnAction(e -> {
                String selectedBg = bgCombo.getValue();
                String color = "#BDC3C7";
                if (selectedBg.contains("#F0F2F5")) color = "#F0F2F5";
                else if (selectedBg.contains("#222222")) color = "#222222";
                else if (selectedBg.contains("#BDC3C7")) color = "#BDC3C7";
                else color = "#FFFFFF";
                String font = fontCombo.getValue();
                String fontSize = fontSizeCombo.getValue();
                String style = "-fx-background-color:" + color + ";" +
                        "-fx-font-family: '" + font + "'; -fx-font-size: " + fontSize + "px; -fx-text-fill: #222;";
                // 设置主内容区样式（TabPane除外）
                if (mainContentStatic != null) {
                    mainContentStatic.setStyle(style);
                }
                // 设置Setting Tab自身背景
                vbox.setStyle("-fx-background-color: " + color + "; -fx-padding: 20;");
            });
            vbox.getChildren().addAll(bgLabel, bgCombo, fontLabel, fontCombo, fontSizeLabel, fontSizeCombo, saveBtn);
            newSettingTab.setContent(vbox);
            mainTabPane.getTabs().add(newSettingTab);
            mainTabPane.getSelectionModel().select(newSettingTab);
        } else {
            mainTabPane.getSelectionModel().select(settingTab);
        }
    }

    public void onHistoryButtonClick(ActionEvent actionEvent) {
        System.out.println("History button clicked");
        func1.hideButtons(); // 强制隐藏Func1和Func2按钮
        if (history != null && mainTabPane != null) {
            history.showHistoryTab(mainTabPane);
        }
    }

    public void onFunctionButtonClick(ActionEvent actionEvent) {
        System.out.println("Function button clicked");
        func1.toggleButtons(); // 切换显示/隐藏
    }

    public void onHelloButtonClick(ActionEvent actionEvent) {
        System.out.println("Hello button clicked");
        //点击Hello按钮时，在界面上显示欢迎文本
        welcomeText.setText("Hello, world!");

    }

    // 新增：背景和字体下拉菜单事件
    public void onBackgroundMenuItemClick(ActionEvent event) {
        if (mainContent != null) {
            mainContent.setStyle("-fx-background-color: #222222;");
        }
    }

    public void onFontMenuItemClick(ActionEvent event) {
        if (mainContent != null) {
            mainContent.setStyle(mainContent.getStyle() +
                    "-fx-font-family: '微软雅黑'; -fx-font-size: 18px; -fx-text-fill: #fff;");
        }
    }

    // 新增：用于禁用/启用主按钮的方法
    public void setMainButtonsDisable(boolean disable) {
        if (settingButton != null) settingButton.setDisable(disable);
        if (historyButton != null) settingButton.setDisable(disable);
        if (functionButton != null) settingButton.setDisable(disable);
        if (helloButton != null) settingButton.setDisable(disable);
    }

    // 新增：func1界面标签页显示方法
    public void showFunc1Tab() {
        if (mainTabPane != null) {
            for (Tab tab : mainTabPane.getTabs()) {
                if ("Functions".equals(tab.getText())) {
                    mainTabPane.getSelectionModel().select(tab);
                    return;
                }
            }
            // 加载FXML作为Functions Tab内容
            try {
                javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("/Controllers/functions-view.fxml"));
                AnchorPane functionsContent = loader.load();
                Tab functionsTab = new Tab("Functions");
                functionsTab.setContent(functionsContent);
                mainTabPane.getTabs().add(functionsTab);
                mainTabPane.getSelectionModel().select(functionsTab);
                refreshImagePreview();
                refreshRecycleBin();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void onHomeButtonClick(ActionEvent actionEvent) {
        if (mainTabPane != null) {
            // 移除所有名为"Home"的Tab
            mainTabPane.getTabs().removeIf(tab -> "Home".equals(tab.getText()));
            // 新建Home Tab并添加
            Tab newHomeTab = new Tab("Home");
            VBox homeContent = new VBox(20);
            homeContent.setAlignment(javafx.geometry.Pos.CENTER);
            Label welcomeLabel = new Label("Welcome to the Home Page!");
            welcomeLabel.setStyle("-fx-font-size: 40px; -fx-font-weight: bold;");
            Button func1Button = createStyledButton("图像转文字", this::onFunc1ButtonClick);
            func1Button.setPrefSize(180, 120);
            func1Button.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #FFFFFF; -fx-text-fill: black; -fx-border-color: black ; -fx-border-width: 4px; -fx-border-style: dashed;");
            // 新增MongoDBPage按钮
            Button mongoDbPageButton = createStyledButton("MongoDBPage", e -> showMongoDBPageTab());
            mongoDbPageButton.setPrefSize(180, 120);
            mongoDbPageButton.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #FFFFFF; -fx-text-fill: #4CAF50; -fx-border-color: #388E3C ; -fx-border-width: 4px; -fx-border-style: dashed;");
            homeContent.getChildren().addAll(welcomeLabel, func1Button, mongoDbPageButton);
            newHomeTab.setContent(homeContent);
            mainTabPane.getTabs().add(0, newHomeTab);
            mainTabPane.getSelectionModel().select(newHomeTab);
        }
    }

    public void onFunc1ButtonClick(ActionEvent actionEvent) {
        showFunc1Tab();
    }

    public void onFunc2ButtonClick(ActionEvent actionEvent) {
        Func1.main(null); // 调用Func1类中的main方法
    }

    // 导入图片按钮事件，支持批量导入
    @FXML
    public void onImportImageButtonClick(ActionEvent actionEvent) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("选择图片");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("图片文件", "*.png", "*.jpg", "*.jpeg", "*.bmp", "*.gif")
        );
        Window window = null;
        if (mainContent != null && mainContent.getScene() != null) {
            window = mainContent.getScene().getWindow();
        }
        List<File> files = fileChooser.showOpenMultipleDialog(window);
        if (files != null && !files.isEmpty()) {
            for (File file : files) {
                if (!importedImages.contains(file) && !recycleBinImages.contains(file)) {
                    importedImages.add(file);
                }
            }
            refreshImagePreview();
        }
    }

    // 刷新图片预览，支持批量删除
    private void refreshImagePreview() {
        if (imagePreviewPane == null) return;
        imagePreviewPane.getChildren().clear();
        for (File file : importedImages) {
            VBox vbox = new VBox(5);
            vbox.setStyle("-fx-background-color: #FFFFFF; -fx-border-color: black; -fx-border-width: 4px; -fx-border-style: dashed; -fx-padding: 8;");
            ImageView imgView = new ImageView(new Image(file.toURI().toString()));
            imgView.setFitWidth(120);
            imgView.setFitHeight(90);
            imgView.setPreserveRatio(true);
            // 新增：点击图片放大查看
            imgView.setOnMouseClicked(e -> showImageInLargeView(file));
            Button delBtn = new Button("删除");
            delBtn.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #FFFFFF; -fx-text-fill: black; -fx-border-color: black; -fx-border-width: 2px; -fx-border-style: dashed;");
            delBtn.setOnAction(e -> {
                importedImages.remove(file);
                recycleBinImages.add(file);
                refreshImagePreview();
                refreshRecycleBin();
            });
            vbox.getChildren().addAll(imgView, delBtn);
            imagePreviewPane.getChildren().add(vbox);
        }
    }

    private void refreshRecycleBin() {
        if (recycleBinPane == null) return;
        recycleBinPane.getChildren().clear();
        for (File file : recycleBinImages) {
            VBox vbox = new VBox(5);
            vbox.setStyle("-fx-background-color: #FFFFFF; -fx-border-color: black; -fx-border-width: 4px; -fx-border-style: dashed; -fx-padding: 8;");
            ImageView imgView = new ImageView(new Image(file.toURI().toString()));
            imgView.setFitWidth(120);
            imgView.setFitHeight(90);
            imgView.setPreserveRatio(true);
            // 新增：点击图片放大查看（回收站）
            imgView.setOnMouseClicked(e -> showImageInLargeView(file));
            Button restoreBtn = new Button("恢复");
            restoreBtn.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #FFFFFF; -fx-text-fill: black; -fx-border-color: black; -fx-border-width: 2px; -fx-border-style: dashed;");
            restoreBtn.setOnAction(e -> {
                recycleBinImages.remove(file);
                importedImages.add(file);
                refreshImagePreview();
                refreshRecycleBin();
            });
            Button deleteBtn = new Button("彻底删除");
            deleteBtn.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #FFFFFF; -fx-text-fill: black; -fx-border-color: black; -fx-border-width: 2px; -fx-border-style: dashed;");
            deleteBtn.setOnAction(e -> {
                recycleBinImages.remove(file);
                refreshRecycleBin();
            });
            vbox.getChildren().addAll(imgView, restoreBtn, deleteBtn);
            recycleBinPane.getChildren().add(vbox);
        }
    }

    @FXML
    public void onRecycleBinButtonClick(ActionEvent actionEvent) {
        if (recycleBinScrollPane != null) {
            boolean show = !recycleBinScrollPane.isVisible();
            recycleBinScrollPane.setVisible(show);
            recycleBinScrollPane.setManaged(show);
        }
    }

    // 图片识别按钮事件，支持批量识别
    @FXML
    public void onRecognizeButtonClick(ActionEvent actionEvent) {
        if (importedImages.isEmpty()) {
            if (functionsResultTextArea != null) {
                functionsResultTextArea.setText("请先导入图片");
            } else if (resultTextArea != null) {
                resultTextArea.setText("请先导入图片");
            }
            return;
        }
        StringBuilder allResult = new StringBuilder();
        for (File file : importedImages) {
            String result = imaRecognize.recognizeImage(file.getAbsolutePath(), "chi_sim");
            allResult.append("【").append(file.getName()).append("】\n");
            allResult.append(result).append("\n\n");
        }
        if (functionsResultTextArea != null) {
            functionsResultTextArea.setText(allResult.toString());
        } else if (resultTextArea != null) {
            resultTextArea.setText(allResult.toString());
        }
    }

    // 导出为TXT按钮事件，支持批量导出
    @FXML
    public void onExportTxtButtonClick(ActionEvent actionEvent) {
        String text = "";
        if (functionsResultTextArea != null && functionsResultTextArea.isVisible()) {
            text = functionsResultTextArea.getText();
        } else if (resultTextArea != null) {
            text = resultTextArea.getText();
        }
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("保存为txt文件");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("文本文件", "*.txt"));
        Window window = null;
        if (mainContent != null && mainContent.getScene() != null) {
            window = mainContent.getScene().getWindow();
        }
        File file = fileChooser.showSaveDialog(window);
        if (file != null) {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(text);
                System.out.println("已导出为txt: " + file.getAbsolutePath());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // 新增：清除所有图片按钮事件
    @FXML
    public void onClearAllImagesButtonClick(ActionEvent actionEvent) {
        importedImages.clear();
        refreshImagePreview();
        refreshRecycleBin();
    }

    /**
     * "将txt文件传输至数据库"按钮事件（支持批量）
     */
    @FXML
    public void onImportTxtToDbButtonClick(ActionEvent actionEvent) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("选择要导入数据库的txt文件（可多选）");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("文本文件", "*.txt"));
        Window window = null;
        if (mainContent != null && mainContent.getScene() != null) {
            window = mainContent.getScene().getWindow();
        }
        List<File> files = fileChooser.showOpenMultipleDialog(window);
        if (files != null && !files.isEmpty()) {
            for (File file : files) {
                try {
                    String content = java.nio.file.Files.readString(file.toPath());
                    Dao.MongoDB.saveTxtToDb(file.getName(), content);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            showMongoDBPageTab(); // 打开MongoDB可视化Tab
        }
    }

    /**
     * 显示MongoDBPage Tab，包含数据库可视化界面（支持批量导出）
     */
    public void showMongoDBPageTab() {
        if (mainTabPane != null) {
            for (Tab tab : mainTabPane.getTabs()) {
                if ("MongoDBPage".equals(tab.getText())) {
                    mainTabPane.getSelectionModel().select(tab);
                    refreshMongoDBPage(tab);
                    return;
                }
            }
            Tab mongoTab = new Tab("MongoDBPage");
            VBox vbox = new VBox(15);
            vbox.setStyle("-fx-background-color: #222222; -fx-padding: 20;");
            Label title = new Label("MongoDB数据库可视化");
            title.setStyle("-fx-text-fill: #fff; -fx-font-size: 22px; -fx-font-weight: bold;");
            ListView<String> fileList = new ListView<>();
            fileList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
            fileList.setPrefHeight(200);
            fileList.setStyle("-fx-font-size: 16px;");
            java.util.List<String> dbFiles = Dao.MongoDB.listTxtFiles();
            fileList.getItems().addAll(dbFiles);
            // 新增：双击文件名显示内容预览
            fileList.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2) {
                    String selected = fileList.getSelectionModel().getSelectedItem();
                    if (selected != null) {
                        String txtContent = Dao.MongoDB.getTxtContent(selected);
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("文件内容预览");
                        alert.setHeaderText(selected);
                        TextArea area = new TextArea(txtContent);
                        area.setEditable(false);
                        area.setWrapText(true);
                        area.setPrefWidth(500);
                        area.setPrefHeight(300);
                        alert.getDialogPane().setContent(area);
                        alert.showAndWait();
                    }
                }
            });
            // 导入按钮
            Button importBtn = new Button("导入txt文件");
            importBtn.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #8BC34A; -fx-text-fill: #fff;");
            importBtn.setOnAction(e -> {
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("选择要导入数据库的txt文件（可多选）");
                fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("文本文件", "*.txt"));
                Window window = mainContent != null && mainContent.getScene() != null ? mainContent.getScene().getWindow() : null;
                List<File> files = fileChooser.showOpenMultipleDialog(window);
                if (files != null && !files.isEmpty()) {
                    for (File file : files) {
                        try {
                            String content = java.nio.file.Files.readString(file.toPath());
                            Dao.MongoDB.saveTxtToDb(file.getName(), content);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                    fileList.getItems().clear();
                    fileList.getItems().addAll(Dao.MongoDB.listTxtFiles());
                }
            });
            // 刷新按钮
            Button refreshBtn = new Button("刷新");
            refreshBtn.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #2196F3; -fx-text-fill: #fff;");
            refreshBtn.setOnAction(e -> {
                fileList.getItems().clear();
                fileList.getItems().addAll(Dao.MongoDB.listTxtFiles());
            });
            // 批量导出按钮
            Button exportBtn = new Button("批量导出选中文件为txt");
            exportBtn.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #4CAF50; -fx-text-fill: #fff;");
            exportBtn.setOnAction(e -> {
                List<String> selectedFiles = fileList.getSelectionModel().getSelectedItems();
                if (selectedFiles != null && !selectedFiles.isEmpty()) {
                    for (String selected : selectedFiles) {
                        String txtContent = Dao.MongoDB.getTxtContent(selected);
                        FileChooser fc = new FileChooser();
                        fc.setTitle("导出txt文件: " + selected);
                        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("文本文件", "*.txt"));
                        fc.setInitialFileName(selected);
                        File saveFile = fc.showSaveDialog(mainContent.getScene().getWindow());
                        if (saveFile != null) {
                            try (FileWriter writer = new FileWriter(saveFile)) {
                                writer.write(txtContent);
                            } catch (IOException ex) {
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            });
            // 删除按钮
            Button deleteBtn = new Button("删除选中文件");
            deleteBtn.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #F44336; -fx-text-fill: #fff;");
            deleteBtn.setOnAction(e -> {
                List<String> selectedFiles = fileList.getSelectionModel().getSelectedItems();
                if (selectedFiles != null && !selectedFiles.isEmpty()) {
                    for (String selected : new ArrayList<>(selectedFiles)) {
                        Dao.MongoDB.deleteTxtFile(selected);
                    }
                    fileList.getItems().clear();
                    fileList.getItems().addAll(Dao.MongoDB.listTxtFiles());
                }
            });
            HBox btnBox = new HBox(10, importBtn, refreshBtn, exportBtn, deleteBtn);
            vbox.getChildren().addAll(title, fileList, btnBox);
            mongoTab.setContent(vbox);
            mainTabPane.getTabs().add(mongoTab);
            mainTabPane.getSelectionModel().select(mongoTab);
        }
    }

    /**
     * 刷新MongoDBPage Tab内容
     */
    private void refreshMongoDBPage(Tab mongoTab) {
        if (mongoTab.getContent() instanceof VBox && ((VBox) mongoTab.getContent()).getChildren().size() >= 2) {
            VBox vbox = (VBox) mongoTab.getContent();
            ListView<String> fileList = (ListView<String>) vbox.getChildren().get(1);
            fileList.getItems().clear();
            java.util.List<String> dbFiles = Dao.MongoDB.listTxtFiles();
            fileList.getItems().addAll(dbFiles);
        }
    }

    /**
     * 工具方法：创建带统一样式的按钮
     */
    public static Button createStyledButton(String text, javafx.event.EventHandler<ActionEvent> handler) {
        Button button = new Button(text);
        javafx.scene.shape.Rectangle roundRect = new javafx.scene.shape.Rectangle(30, 30);
        roundRect.setArcWidth(10);
        roundRect.setArcHeight(10);
        button.setShape(roundRect);
        button.setPrefSize(180, 120);
        button.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: #FFFFFF; -fx-text-fill: black;" +
                "-fx-border-color: black ; -fx-border-width: 4px; -fx-border-style: dashed;");
        if (handler != null) button.setOnAction(handler);
        return button;
    }

    /**
     * 工具方法：创建带统一样式的Tab内容VBox+Label
     */
    public static VBox createStyledTabContent(String labelText, String labelStyle, String vboxStyle) {
        VBox vbox = new VBox(20);
        vbox.setAlignment(javafx.geometry.Pos.CENTER);
        if (vboxStyle != null) vbox.setStyle(vboxStyle);
        Label label = new Label(labelText);
        if (labelStyle != null) label.setStyle(labelStyle);
        vbox.getChildren().add(label);
        return vbox;
    }

    private void showImageInLargeView(File file) {
        javafx.scene.image.ImageView largeImageView = new javafx.scene.image.ImageView(new javafx.scene.image.Image(file.toURI().toString()));
        largeImageView.setPreserveRatio(true);
        largeImageView.setFitWidth(800);
        largeImageView.setFitHeight(600);
        javafx.scene.layout.StackPane pane = new javafx.scene.layout.StackPane(largeImageView);
        javafx.scene.Scene scene = new javafx.scene.Scene(pane, 820, 620);
        javafx.stage.Stage stage = new javafx.stage.Stage();
        stage.setTitle(file.getName());
        stage.setScene(scene);
        stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
        stage.show();
    }
}
