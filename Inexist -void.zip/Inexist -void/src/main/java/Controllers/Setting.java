package Controllers;

import javafx.geometry.Rectangle2D;
import javafx.scene.paint.Color;
import javafx.stage.Screen;

public class Setting {
    // 通用设置
    Rectangle2D screenBounds = Screen.getPrimary().getBounds();
    double screenWidth = screenBounds.getWidth() * 0.75;
    double screenHeight = screenBounds.getHeight() * 0.75;

    public Color getBackgroundColor() {
        return Color.RED;
    }

    // 显示Setting界面
    public static void toggleSetting() {
        if (settingStageRef == null || !settingStageRef.isShowing()) {
            showSetting();
        } else {
            hideSetting();
        }
    }

    public static void showSetting() {
        if (settingStageRef != null && settingStageRef.isShowing()) {
            return;
        }
        javafx.stage.Stage settingStage = new javafx.stage.Stage();
        settingStage.initModality(javafx.stage.Modality.NONE);
        settingStageRef = settingStage;
        settingStage.setTitle("设置");
        javafx.scene.layout.VBox vbox = new javafx.scene.layout.VBox();
        vbox.setSpacing(20);
        vbox.setStyle("-fx-padding: 20;");
        javafx.scene.control.Label label = new javafx.scene.control.Label("请选择背景颜色：");
        javafx.scene.control.ComboBox<String> bgCombo = new javafx.scene.control.ComboBox<>();
        bgCombo.getItems().addAll("默认", "浅灰 #F0F2F5", "深灰 #222222", "蓝灰 #BDC3C7");
        bgCombo.setValue("蓝灰 #BDC3C7");
        javafx.scene.control.Button saveBtn = new javafx.scene.control.Button("保存更改");
        saveBtn.setOnAction(e -> {
            String selected = bgCombo.getValue();
            if (selected != null) {
                String color = "#BDC3C7";
                if (selected.contains("#F0F2F5")) color = "#F0F2F5";
                else if (selected.contains("#222222")) color = "#222222";
                else if (selected.contains("#BDC3C7")) color = "#BDC3C7";
                else color = "#FFFFFF";
                if (Controllers.Controller.mainContentStatic != null) {
                    Controllers.Controller.mainContentStatic.setStyle("-fx-background-color:" + color + ";" +
                            "-fx-font-family: '微软雅黑'; -fx-font-size: 18px; -fx-text-fill: #fff;");
                }
            }
        });
        vbox.getChildren().addAll(label, bgCombo, saveBtn);
        javafx.scene.Scene scene = new javafx.scene.Scene(vbox, 350, 200);
        settingStage.setScene(scene);
        settingStage.setAlwaysOnTop(true);
        settingStage.show();
        settingStage.setOnCloseRequest(event -> hideSetting());
    }

    public static javafx.stage.Stage settingStageRef = null;

    public static void hideSetting() {
        if (settingStageRef != null) {
            settingStageRef.close();
            settingStageRef = null;
            // 尝试恢复主按钮可用
            try {
                Controllers.Controller controller = getControllerInstance();
                if (controller != null) {
                    controller.setMainButtonsDisable(false);
                }
            } catch (Exception ignored) {}
        }
    }

    // 获取Controller实例（如无法获取则返回null）
    public static Controllers.Controller getControllerInstance() {
        return null;
    }

    public static void SettingChange() {
        if (Controllers.Controller.mainContentStatic != null) {
            Controllers.Controller.mainContentStatic.setStyle("-fx-background-color:#BDC3C7;" +
                    "-fx-font-family: '微软雅黑'; -fx-font-size: 18px; -fx-text-fill: #fff;");
        }
    }
}
