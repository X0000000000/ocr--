package Controllers.Func;

import Services.imaRecognize;

public class imaReconFun {
    public static void  imaReconFun() {
        //连接运行imaRecognize
        System.out.println("imaReconFun");
    }
    public static void main(String[] args) {
            imaReconFun();
        imaRecognize.main(args);
    }
}
