module com.example.inexist {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;

    requires org.mongodb.driver.core;
    requires org.mongodb.bson;
    requires org.mongodb.driver.sync.client;
    requires py4j;
    requires tess4j;
    requires java.management;
    requires org.bytedeco.opencv;

    opens Controllers to javafx.fxml;
    exports Controllers;
}

