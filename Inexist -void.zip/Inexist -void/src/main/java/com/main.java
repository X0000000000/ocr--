package com;


import Controllers.MainApplication;

public class main {
    public static void main(String[] args) {
        System.out.println("Progress Running...");
        //运行Controllers中的MainApplication.java
        MainApplication.main(args);

    }
}
